<?php
header('Content-Type: application/json; charset=utf-8');

// 设备目录结构
$base_dir = 'devices/';
$registered_dir = $base_dir . 'registered/';

// 处理POST请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取设备信息
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data || !isset($data['device_id'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => '缺少设备ID']);
        exit;
    }

    $device_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['device_id']); // 安全过滤
    $device_dir = $registered_dir . $device_id . '/';
    
    // 检查设备是否已注册
    if (!file_exists($device_dir)) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => '设备未注册']);
        exit;
    }

    // 更新设备状态
    $status_file = $device_dir . 'status.json';
    $status_info = [
        'online' => true,
        'last_online' => date('Y-m-d H:i:s'),
        'last_command_time' => null
    ];
    
    if (file_exists($status_file)) {
        $current_status = json_decode(file_get_contents($status_file), true);
        $status_info['last_command_time'] = $current_status['last_command_time'];
    }
    
    file_put_contents($status_file, json_encode($status_info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    // 更新在线设备列表
    $online_file = $base_dir . 'online.json';
    $online_devices = [];
    
    if (file_exists($online_file)) {
        $online_data = json_decode(file_get_contents($online_file), true);
        $online_devices = isset($online_data['devices']) ? $online_data['devices'] : [];
    }

    // 更新设备心跳时间
    $device_updated = false;
    foreach ($online_devices as &$device) {
        if ($device['device_id'] === $device_id) {
            $device['last_heartbeat'] = date('Y-m-d H:i:s');
            $device_updated = true;
            break;
        }
    }

    // 如果设备不在列表中，获取设备信息并添加
    if (!$device_updated) {
        $info_file = $device_dir . 'info.json';
        if (file_exists($info_file)) {
            $device_info = json_decode(file_get_contents($info_file), true);
            $online_devices[] = [
                'device_id' => $device_id,
                'device_name' => $device_info['device_name'],
                'last_heartbeat' => date('Y-m-d H:i:s')
            ];
        }
    }

    file_put_contents($online_file, json_encode(['devices' => $online_devices], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    // 检查是否有待执行的命令
    $pending_dir = $device_dir . 'commands/pending/';
    $pending_commands = [];
    
    if (file_exists($pending_dir)) {
        $files = glob($pending_dir . '*.json');
        foreach ($files as $file) {
            $command = json_decode(file_get_contents($file), true);
            $pending_commands[] = $command;
            
            // 将命令移动到历史记录
            $history_file = str_replace('/pending/', '/history/', $file);
            rename($file, $history_file);
        }
    }

    // 返回成功响应和待执行的命令
    echo json_encode([
        'status' => 'success',
        'message' => '心跳更新成功',
        'pending_commands' => $pending_commands
    ]);
} else {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => '请使用POST方法']);
}
?> 