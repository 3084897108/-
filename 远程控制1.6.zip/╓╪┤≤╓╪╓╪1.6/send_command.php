<?php
header('Content-Type: text/html; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $command = isset($_POST['command']) ? $_POST['command'] : '';
    $device_id = isset($_POST['device_id']) ? $_POST['device_id'] : '';
    
    if (empty($command)) {
        echo "指令不能为空";
        exit;
    }

    if (empty($device_id)) {
        echo "请选择目标设备";
        exit;
    }
    
    // 准备发送到指定设备的命令数据
    $command_data = [
        'device_id' => $device_id,
        'command' => $command
    ];

    // 发送命令到新的命令处理接口
    $ch = curl_init('send_device_command.php');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($command_data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response === false) {
        echo "命令发送失败";
    } else {
        $result = json_decode($response, true);
        if ($result['status'] === 'success') {
            echo "命令发送成功：" . htmlspecialchars($command);
        } else {
            echo "命令发送失败：" . $result['message'];
        }
    }
} else {
    echo "请使用POST方法访问";
}
?> 