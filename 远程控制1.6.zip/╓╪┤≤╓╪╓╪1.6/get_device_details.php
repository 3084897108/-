<?php
header('Content-Type: application/json; charset=utf-8');

// 设备目录结构
$base_dir = 'devices/';
$registered_dir = $base_dir . 'registered/';

if (!isset($_GET['device_id'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => '缺少设备ID']);
    exit;
}

$device_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['device_id']);
$device_dir = $registered_dir . $device_id . '/';
$info_file = $device_dir . 'info.json';
$status_file = $device_dir . 'status.json';

if (!file_exists($info_file) || !file_exists($status_file)) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => '设备不存在']);
    exit;
}

// 读取设备信息
$device_info = json_decode(file_get_contents($info_file), true);
$status_info = json_decode(file_get_contents($status_file), true);

// 合并设备信息
$device_data = array_merge($device_info, $status_info);

echo json_encode([
    'status' => 'success',
    'device' => $device_data
]);
?> 