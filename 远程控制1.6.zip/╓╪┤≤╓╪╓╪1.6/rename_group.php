<?php
header('Content-Type: application/json; charset=utf-8');

$base_dir = 'devices/';
$groups_file = $base_dir . 'groups.json';

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['old_name']) || !isset($data['new_name'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => '缺少必要参数']);
    exit;
}

$old_name = trim($data['old_name']);
$new_name = trim($data['new_name']);

// 检查新名称是否为空
if (empty($new_name)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => '新分组名称不能为空']);
    exit;
}

// 读取分组信息
if (!file_exists($groups_file)) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => '分组文件不存在']);
    exit;
}

$groups = json_decode(file_get_contents($groups_file), true);

// 检查旧分组是否存在
if (!isset($groups[$old_name])) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => '原分组不存在']);
    exit;
}

// 检查新名称是否已存在
if (isset($groups[$new_name]) && $old_name !== $new_name) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => '新分组名称已存在']);
    exit;
}

// 重命名分组
$group_data = $groups[$old_name];
unset($groups[$old_name]);
$groups[$new_name] = $group_data;

// 保存更新
if (file_put_contents($groups_file, json_encode($groups, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
    echo json_encode(['status' => 'success', 'message' => '分组重命名成功']);
} else {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => '保存分组信息失败']);
}
?> 