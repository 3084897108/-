<?php
header('Content-Type: application/json; charset=utf-8');

$base_dir = 'devices/';
$groups_file = $base_dir . 'groups.json';

// 获取分组内所有设备并执行命令
// ... 