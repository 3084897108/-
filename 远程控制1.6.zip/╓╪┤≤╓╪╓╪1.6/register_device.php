<?php
header('Content-Type: application/json; charset=utf-8');

// 设备目录结构
$base_dir = 'devices/';
$registered_dir = $base_dir . 'registered/';

// 确保目录存在
if (!file_exists($base_dir)) {
    mkdir($base_dir, 0777, true);
}
if (!file_exists($registered_dir)) {
    mkdir($registered_dir, 0777, true);
}

// 处理POST请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取设备信息
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data || !isset($data['device_id'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => '缺少设备ID']);
        exit;
    }

    $device_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['device_id']); // 安全过滤
    $device_dir = $registered_dir . $device_id . '/';
    $commands_dir = $device_dir . 'commands/';
    
    // 创建设备目录结构
    if (!file_exists($device_dir)) {
        mkdir($device_dir, 0777, true);
        mkdir($commands_dir . 'pending', 0777, true);
        mkdir($commands_dir . 'history', 0777, true);
    }

    // 准备设备信息
    $device_info = [
        'device_id' => $device_id,
        'device_name' => isset($data['device_name']) ? $data['device_name'] : $device_id,
        'system_info' => isset($data['system_info']) ? $data['system_info'] : '',
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'register_time' => date('Y-m-d H:i:s')
    ];

    // 设备状态信息
    $status_info = [
        'online' => true,
        'last_online' => date('Y-m-d H:i:s'),
        'last_command_time' => null
    ];

    // 保存设备信息
    $info_file = $device_dir . 'info.json';
    $status_file = $device_dir . 'status.json';
    
    file_put_contents($info_file, json_encode($device_info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    file_put_contents($status_file, json_encode($status_info, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    // 更新在线设备列表
    $online_file = $base_dir . 'online.json';
    $online_devices = [];
    
    if (file_exists($online_file)) {
        $online_data = json_decode(file_get_contents($online_file), true);
        $online_devices = isset($online_data['devices']) ? $online_data['devices'] : [];
    }

    // 检查设备是否已在列表中
    $device_exists = false;
    foreach ($online_devices as &$device) {
        if ($device['device_id'] === $device_id) {
            $device['last_heartbeat'] = date('Y-m-d H:i:s');
            $device['device_name'] = $device_info['device_name'];
            $device_exists = true;
            break;
        }
    }

    // 如果设备不在列表中，添加它
    if (!$device_exists) {
        $online_devices[] = [
            'device_id' => $device_id,
            'device_name' => $device_info['device_name'],
            'last_heartbeat' => date('Y-m-d H:i:s')
        ];
    }

    file_put_contents($online_file, json_encode(['devices' => $online_devices], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    // 返回成功响应
    echo json_encode([
        'status' => 'success',
        'message' => '设备注册成功',
        'device_id' => $device_id
    ]);
} else {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => '请使用POST方法']);
}
?> 