<?php
header('Content-Type: application/json; charset=utf-8');

$base_dir = 'devices/';
$groups_file = $base_dir . 'groups.json';

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['group_name'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => '缺少分组名称']);
    exit;
}

$group_name = trim($data['group_name']);

// 读取现有分组
$groups = [];
if (file_exists($groups_file)) {
    $groups = json_decode(file_get_contents($groups_file), true);
}

// 检查分组名是否已存在
if (isset($groups[$group_name])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => '分组名称已存在']);
    exit;
}

// 创建新分组
$groups[$group_name] = [
    'devices' => [],
    'create_time' => date('Y-m-d H:i:s')
];

// 保存分组信息
if (file_put_contents($groups_file, json_encode($groups, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
    echo json_encode(['status' => 'success', 'message' => '分组创建成功']);
} else {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => '分组创建失败']);
}
?> 