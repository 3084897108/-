<?php
header('Content-Type: application/json; charset=utf-8');

// 设备目录结构
$base_dir = 'devices/';
$registered_dir = $base_dir . 'registered/';

// 处理POST请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取命令信息
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data || !isset($data['device_id']) || !isset($data['command'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => '缺少必要参数']);
        exit;
    }

    $device_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['device_id']);
    $device_dir = $registered_dir . $device_id . '/';
    
    // 检查设备是否存在
    if (!file_exists($device_dir)) {
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => '设备未注册']);
        exit;
    }

    // 检查设备是否在线
    $status_file = $device_dir . 'status.json';
    if (file_exists($status_file)) {
        $status = json_decode(file_get_contents($status_file), true);
        $last_online = strtotime($status['last_online']);
        if (time() - $last_online > 60) { // 如果超过60秒没有心跳，认为设备离线
            http_response_code(503);
            echo json_encode(['status' => 'error', 'message' => '设备离线']);
            exit;
        }
    }

    // 准备命令数据
    $command_data = [
        'id' => uniqid(),
        'command' => $data['command'],
        'params' => isset($data['params']) ? $data['params'] : [],
        'create_time' => date('Y-m-d H:i:s')
    ];

    // 保存命令到待执行目录
    $pending_dir = $device_dir . 'commands/pending/';
    if (!file_exists($pending_dir)) {
        mkdir($pending_dir, 0777, true);
    }

    $command_file = $pending_dir . $command_data['id'] . '.json';
    if (file_put_contents($command_file, json_encode($command_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
        // 更新设备状态中的最后命令时间
        if (file_exists($status_file)) {
            $status = json_decode(file_get_contents($status_file), true);
            $status['last_command_time'] = date('Y-m-d H:i:s');
            file_put_contents($status_file, json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        echo json_encode([
            'status' => 'success',
            'message' => '命令已发送',
            'command_id' => $command_data['id']
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => '命令保存失败']);
    }
} else {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => '请使用POST方法']);
}
?> 