<?php
header('Content-Type: text/html; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $command = isset($_POST['command']) ? $_POST['command'] : '';
    
    if (!empty($command)) {
        $file = 'command.txt';
        
        // 检查文件是否存在和可写
        if (!file_exists($file)) {
            touch($file);
            chmod($file, 0666);
        }
        
        if (is_writable($file)) {
            if (file_put_contents($file, $command) !== false) {
                echo "命令已写入: " . $command;
            } else {
                echo "写入失败";
                error_log("写入command.txt失败");
            }
        } else {
            echo "文件不可写";
            error_log("command.txt不可写");
        }
    } else {
        echo "指令不能为空";
    }
} else {
    echo "请使用POST方法访问";
}
?> 