<?php
header('Content-Type: application/json; charset=utf-8');

$base_dir = 'devices/';
$groups_file = $base_dir . 'groups.json';

// 读取分组信息
$groups = [];
if (file_exists($groups_file)) {
    $groups = json_decode(file_get_contents($groups_file), true);
}

echo json_encode([
    'status' => 'success',
    'groups' => $groups
]);
?> 