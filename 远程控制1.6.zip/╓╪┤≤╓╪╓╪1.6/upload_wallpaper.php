<?php
header('Content-Type: text/html; charset=utf-8');

$wallpaper_dir = 'wallpapers/';  // 壁纸存储目录

// 如果目录不存在则创建
if (!file_exists($wallpaper_dir)) {
    mkdir($wallpaper_dir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['wallpaper'])) {
    $file = $_FILES['wallpaper'];
    
    // 检查文件类型
    $allowed_types = ['image/jpeg', 'image/png', 'image/bmp'];
    if (!in_array($file['type'], $allowed_types)) {
        echo "只允许上传 JPG、PNG 或 BMP 格式的图片";
        exit;
    }
    
    // 使用原始文件名
    $filename = $file['name'];
    $filepath = $wallpaper_dir . $filename;
    
    // 如果文件已存在，先删除
    if (file_exists($filepath)) {
        unlink($filepath);
    }
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        echo "上传成功: " . $filename;  // 返回文件名
    } else {
        echo "上传失败";
    }
} else {
    echo "请使用POST方法上传文件";
}
?> 