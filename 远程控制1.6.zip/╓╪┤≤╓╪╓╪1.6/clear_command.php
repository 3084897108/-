<?php
header('Content-Type: text/html; charset=utf-8');

$file = 'command.txt';

// 清空文件内容
if (file_exists($file)) {
    if (file_put_contents($file, '') !== false) {
        echo "指令已清空";
    } else {
        echo "清空失败";
        error_log("清空command.txt失败");
    }
} else {
    // 如果文件不存在，创建一个空文件
    if (touch($file)) {
        echo "指令已清空";
    } else {
        echo "创建文件失败";
        error_log("创建command.txt失败");
    }
}
?> 