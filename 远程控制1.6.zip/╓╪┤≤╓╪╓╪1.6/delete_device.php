<?php
header('Content-Type: application/json; charset=utf-8');

// 设备目录结构
$base_dir = 'devices/';
$registered_dir = $base_dir . 'registered/';
$online_file = $base_dir . 'online.json';

// 获取POST数据
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['device_id'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => '缺少设备ID']);
    exit;
}

$device_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $data['device_id']);
$device_dir = $registered_dir . $device_id;

// 删除设备目录
if (file_exists($device_dir)) {
    // 递归删除目录及其内容
    function deleteDirectory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
                return false;
            }
        }
        return rmdir($dir);
    }
    
    if (deleteDirectory($device_dir)) {
        // 从在线设备列表中移除
        if (file_exists($online_file)) {
            $online_data = json_decode(file_get_contents($online_file), true);
            if (isset($online_data['devices'])) {
                $online_data['devices'] = array_filter($online_data['devices'], function($device) use ($device_id) {
                    return $device['device_id'] !== $device_id;
                });
                file_put_contents($online_file, json_encode($online_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
        }
        
        echo json_encode(['status' => 'success', 'message' => '设备删除成功']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => '删除设备失败']);
    }
} else {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => '设备不存在']);
}
?> 