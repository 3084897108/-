<?php
header('Content-Type: application/json; charset=utf-8');

// 设备目录结构
$base_dir = 'devices/';
$online_file = $base_dir . 'online.json';

// 获取在线设备列表
$devices = [];
if (file_exists($online_file)) {
    $online_data = json_decode(file_get_contents($online_file), true);
    if (isset($online_data['devices'])) {
        foreach ($online_data['devices'] as $device) {
            $last_heartbeat = strtotime($device['last_heartbeat']);
            $is_online = (time() - $last_heartbeat <= 60); // 60秒内有心跳的认为是在线的
            
            $devices[] = [
                'device_id' => $device['device_id'],
                'device_name' => $device['device_name'],
                'online' => $is_online,
                'last_heartbeat' => $device['last_heartbeat']
            ];
        }
    }
}

echo json_encode([
    'status' => 'success',
    'devices' => $devices
]);
?> 